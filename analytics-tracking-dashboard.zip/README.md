# Analytics & Tracking Dashboard

## Quick start
1. Extract into your Next.js 14 App Router project root.
2. `cp .env.example .env.local` (keep `NEXT_PUBLIC_USE_MOCK=1` for demo).
3. Install deps: `npm i zod zustand` (or `pnpm add zod zustand`).
4. Ensure TS path alias supports `@/*`:
   - In `tsconfig.json` add:
   ```json
   {
     "compilerOptions": {
       "baseUrl": ".",
       "paths": { "@/*": ["*"] }
     }
   }
   ```
5. `npm run dev` then open `/dashboard`.

## Real data
- Set `NEXT_PUBLIC_USE_MOCK=0`.
- Implement GA4 / Meta logic in:
  - `app/api/connect/[key]/route.ts`
  - `app/api/metrics/[key]/route.ts`

## Notes
- Zod validates payloads.
- Toasts replace alerts.
- UI atoms are reusable.
