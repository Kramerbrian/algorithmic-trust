import { z } from 'zod';

export const ConnectBody = z.object({
  id: z.string().min(3, 'id required'),
});
export type ConnectBody = z.infer<typeof ConnectBody>;

export const ConnectorKey = z.enum(['ga','fb']);
export type ConnectorKey = z.infer<typeof ConnectorKey>;
