// Types and connector config
import type { ConnectorKey } from './zod';

export type GAData = {
  visitors: number; visitorChange: number;
  leads: number; leadChange: number;
  conversionRate: number; conversionChange: number;
  avgTimeOnSite: string; timeChange: number;
  bounceRate: number; bounceChange: number;
  mobileTraffic: number; mobileChange: number;
};
export type FBData = {
  adClicks: number; costPerClick: number;
  leadsFromAds: number; costPerLead: number;
  vehicleViews: number; adSpend: number;
};

export type Connector<T> = {
  key: ConnectorKey;
  title: string;
  icon: string;
  placeholder: string;
  connectBtnClass: string;
  connectBannerClass: string;
  connectBannerTitle: string;
  connectBannerText?: string;
  mock: T;
  toCards: (d: T) => { label: string; value: string; sub?: string; subClass?: string }[];
  code: (id: string) => string;
};

const GA_CODE = (id: string) => `<!-- Add to <head> -->
<script async src="https://www.googletagmanager.com/gtag/js?id=${id || 'G-XXXXXXXXXX'}"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', '${id || 'G-XXXXXXXXXX'}');
</script>`;

const FB_CODE = (id: string) => `<!-- Facebook Pixel -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}
(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init','${id || 'YOUR_PIXEL_ID'}');fbq('track','PageView');
</script>`;

export const MOCK_GA: GAData = {
  visitors: 5247, visitorChange: 12,
  leads: 127, leadChange: -5,
  conversionRate: 2.4, conversionChange: -0.3,
  avgTimeOnSite: '3:42', timeChange: 22,
  bounceRate: 58, bounceChange: 3,
  mobileTraffic: 73, mobileChange: 2
};

export const MOCK_FB: FBData = {
  adClicks: 1892, costPerClick: 2.34,
  leadsFromAds: 47, costPerLead: 94,
  vehicleViews: 3241, adSpend: 4428
};

export const CONNECTORS: Record<ConnectorKey, Connector<any>> = {
  ga: {
    key: 'ga',
    title: 'Google Analytics 4 — Customer Behavior',
    icon: '📈',
    placeholder: 'GA4 Measurement ID (G-XXXXXXXXXX)',
    connectBtnClass: 'bg-green-600',
    connectBannerClass: 'bg-yellow-50 border border-yellow-200',
    connectBannerTitle: 'Connect GA4',
    mock: MOCK_GA,
    toCards: (d: GAData) => [
      { label: 'Monthly Visitors', value: d.visitors.toLocaleString() },
      { label: 'Lead Forms Submitted', value: d.leads.toLocaleString() },
      { label: 'Conversion Rate', value: `${d.conversionRate}%` },
      { label: 'Avg Time on Site', value: d.avgTimeOnSite },
      { label: 'Bounce Rate', value: `${d.bounceRate}%` },
      { label: 'Mobile Traffic', value: `${d.mobileTraffic}%` },
    ],
    code: GA_CODE,
  },
  fb: {
    key: 'fb',
    title: 'Facebook Pixel — Ad Performance',
    icon: '👥',
    placeholder: 'Facebook Pixel ID',
    connectBtnClass: 'bg-blue-600',
    connectBannerClass: 'bg-red-50 border border-red-200',
    connectBannerTitle: 'Connect Facebook Pixel',
    connectBannerText: 'No Pixel = poor optimization and attribution.',
    mock: MOCK_FB,
    toCards: (d: FBData) => [
      { label: 'FB/IG Ad Clicks', value: d.adClicks.toLocaleString(), sub: `$${d.costPerClick} per click`, subClass: 'text-blue-600' },
      { label: 'Leads from Ads', value: String(d.leadsFromAds), sub: `$${d.costPerLead} per lead`, subClass: 'text-blue-600' },
      { label: 'Vehicle Views from Ads', value: d.vehicleViews.toLocaleString(), sub: 'High intent!', subClass: 'text-green-600' },
    ],
    code: FB_CODE,
  },
};
