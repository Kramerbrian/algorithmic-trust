import { create } from 'zustand';

type Toast = { id: number; title: string; desc?: string };
type Store = {
  toasts: Toast[];
  push: (t: Omit<Toast,'id'>) => void;
  remove: (id: number) => void;
};

let idSeq = 1;
export const useToastStore = create<Store>((set) => ({
  toasts: [],
  push: (t) => set((s) => ({ toasts: [...s.toasts, { id: idSeq++, ...t }] })),
  remove: (id) => set((s) => ({ toasts: s.toasts.filter(x => x.id !== id) })),
}));
