'use client';
import React, { useMemo, useReducer } from 'react';
import Badge from '@/components/ui/Badge';
import Section from '@/components/ui/Section';
import CopyBlock from '@/components/ui/CopyBlock';
import Toasts from '@/components/Toast';
import { CONNECTORS } from '@/lib/connectors';
import type { ConnectorKey } from '@/lib/zod';
import { useToastStore } from '@/lib/toast';

type State = {
  loading: boolean;
  ids: Record<ConnectorKey, string>;
  connected: Record<ConnectorKey, boolean>;
  data: Record<string, any>;
};
type Action =
  | { type: 'setId'; key: ConnectorKey; value: string }
  | { type: 'loading'; value: boolean }
  | { type: 'connected'; key: ConnectorKey; value: boolean }
  | { type: 'setData'; key: ConnectorKey; value: any };

const initial: State = { loading: false, ids: { ga: '', fb: '' }, connected: { ga: false, fb: false }, data: {} };

function reducer(s: State, a: Action): State {
  switch (a.type) {
    case 'setId': return { ...s, ids: { ...s.ids, [a.key]: a.value } };
    case 'loading': return { ...s, loading: a.value };
    case 'connected': return { ...s, connected: { ...s.connected, [a.key]: a.value } };
    case 'setData': return { ...s, data: { ...s.data, [a.key]: a.value } };
    default: return s;
  }
}

export default function DashboardPage() {
  const [state, dispatch] = useReducer(reducer, initial);
  const toast = useToastStore();

  const connect = async (key: ConnectorKey) => {
    const id = state.ids[key];
    if (!id) { toast.push({ title: `Enter ${key === 'ga' ? 'GA4 ID' : 'Pixel ID'}` }); return; }
    dispatch({ type: 'loading', value: true });
    const res = await fetch(`/api/connect/${key}`, { method: 'POST', body: JSON.stringify({ id }) });
    if (!res.ok) {
      const { error } = await res.json().catch(() => ({ error: 'connect failed' }));
      toast.push({ title: `Connect ${key.toUpperCase()} failed`, desc: String(error) });
      dispatch({ type: 'loading', value: false });
      return;
    }
    dispatch({ type: 'connected', key, value: true });
    const m = await fetch(`/api/metrics/${key}`).then(r => r.json());
    dispatch({ type: 'setData', key, value: m.data });
    dispatch({ type: 'loading', value: false });
    toast.push({ title: `${key.toUpperCase()} connected` });
  };

  const events = useMemo(() => ([
    ['📞','Phone Calls',false,'Track phone number clicks. ~40% lead signals live here.'],
    ['💬','Chat Opens',false,'Expose engagement currently invisible.'],
    ['📋','Form Starts',true,'See abandons to fix UX.'],
    ['🚗','VDP Views',true,'Identify hot vehicles.'],
    ['💰','Payment Calculator',false,'Strong buying intent. Track it.'],
    ['📍','Directions Clicks',false,'Directions ≈ store visits. Log it.'],
  ] as const), []);

  return (
    <div className="max-w-7xl mx-auto p-6 bg-gray-50 min-h-screen">
      <Toasts />

      <div className="bg-white rounded-xl p-8 mb-8 shadow-sm border-t-4 border-blue-500">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-3">📊 Analytics & Tracking Dashboard</h1>
            <p className="text-lg text-gray-600">Connect GA4 and Facebook Pixel to expose behavior and ad ROI.</p>
          </div>
          <div className="flex gap-4">
            <Badge ok={state.connected.ga} label="GA4 Connected" />
            <Badge ok={state.connected.fb} label="FB Pixel Connected" />
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8 flex gap-3">
        <span className="text-blue-500 text-xl">ℹ️</span>
        <div>
          <div className="font-semibold text-blue-900 mb-1">Why this matters</div>
          <div className="text-blue-700 text-sm">Vitals = speed. GA4 = behavior. Pixel = ad performance. Use all three.</div>
        </div>
      </div>

      <Section icon="🔄" title="What Each Tool Measures">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                {['What We Measure','Core Web Vitals','Google Analytics 4','Facebook Pixel'].map(h=>(
                  <th key={h} className="p-3 text-left font-semibold text-gray-700 border-b-2 border-gray-200">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                ['Page Load Speed','✅ 2.8 seconds','Not Available','Not Available','How fast pages appear'],
                ['Visitor Count','Not Available', state.connected.ga ? '✅ 5,247/month' : '❌ Not Connected', state.connected.fb ? '✅ 4,892/month' : '❌ Not Connected','How many people visit'],
                ['Lead Form Submissions','Not Available', state.connected.ga ? '✅ 127 leads' : '❌ Not Connected', state.connected.fb ? '✅ 118 leads' : '❌ Not Connected','Contact forms filled']
              ].map(([k, cwv, ga, fb, sub], i)=>(
                <tr key={i} className="hover:bg-gray-50">
                  <td className="p-3 border-b border-gray-100">
                    <div className="font-medium text-gray-900">{k}</div>
                    <div className="text-xs text-gray-500">{sub}</div>
                  </td>
                  {[cwv, ga, fb].map((cell,j)=>(
                    <td key={j} className={`p-3 border-b border-gray-100 ${/Not Available|Not Connected/.test(cell) ? 'text-gray-400 italic' : 'font-semibold text-lg'}`}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {(Object.keys(CONNECTORS) as ConnectorKey[]).map((key) => {
        const c = CONNECTORS[key];
        const connected = state.connected[key];
        const data = state.data[key];
        return (
          <Section key={key} icon={c.icon} title={c.title}>
            {!connected ? (
              <div className={`${c.connectBannerClass} rounded-lg p-6 text-center`}>
                <h3 className="text-lg font-semibold mb-2">{c.connectBannerTitle}</h3>
                {c.connectBannerText && <p className="mb-4">{c.connectBannerText}</p>}
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    value={state.ids[key]}
                    onChange={(e)=>dispatch({ type: 'setId', key, value: e.target.value })}
                    placeholder={c.placeholder}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button
                    onClick={()=>connect(key)}
                    disabled={state.loading}
                    className={`px-6 py-2 ${c.connectBtnClass} text-white rounded-lg font-semibold hover:opacity-90 disabled:opacity-50`}
                  >
                    {state.loading ? 'Connecting...' : 'Connect'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {c.toCards(data).map(card => (
                  <div key={card.label} className="bg-gray-50 p-5 rounded-lg border-l-4 border-blue-600">
                    <div className="text-sm text-blue-600 mb-2 font-medium">{card.label}</div>
                    <div className="text-2xl font-bold text-gray-900 mb-2">{card.value}</div>
                    {card.sub && <div className={`text-sm font-semibold ${card.subClass || 'text-blue-600'}`}>{card.sub}</div>}
                  </div>
                ))}
              </div>
            )}
          </Section>
        );
      })}

      <Section icon="🎯" title="Critical Events to Track">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            ['📞','Phone Calls',false,'Track phone number clicks. ~40% lead signals live here.'],
            ['💬','Chat Opens',false,'Expose engagement currently invisible.'],
            ['📋','Form Starts',true,'See abandons to fix UX.'],
            ['🚗','VDP Views',true,'Identify hot vehicles.'],
            ['💰','Payment Calculator',false,'Strong buying intent. Track it.'],
            ['📍','Directions Clicks',false,'Directions ≈ store visits. Log it.'],
          ].map(([icon,name,tracking,desc])=>(
            <div key={name as string} className="bg-gray-50 border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-center mb-3">
                <span className="font-semibold text-gray-900">{icon} {name}</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${tracking ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {tracking ? 'TRACKING' : 'NOT TRACKING'}
                </span>
              </div>
              <div className="text-sm text-gray-600">{desc}</div>
            </div>
          ))}
        </div>
      </Section>

      <Section icon="🔧" title="Setup Code — Copy & Paste">
        <div className="space-y-6">
          <CopyBlock title="Google Analytics 4" code={CONNECTORS.ga.code(state.ids.ga)} />
          <CopyBlock title="Facebook Pixel" code={CONNECTORS.fb.code(state.ids.fb)} />
        </div>
      </Section>

      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-6 pb-4 border-b-2 border-gray-200">
          <span className="text-2xl">💡</span>
          <h2 className="text-2xl font-bold text-gray-900">What Proper Tracking Gets You</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {[
            { n:'-$47', t:'Lower CPL with FB optimization', c:'text-blue-600' },
            { n:'+38%', t:'More leads from same ad budget', c:'text-green-600' },
            { n:'2.8x', t:'Better ROAS', c:'text-purple-600' }
          ].map(k=>(
            <div key={k.t} className="text-center">
              <div className={`text-3xl font-bold ${k.c} mb-2`}>{k.n}</div>
              <div className="text-gray-600">{k.t}</div>
            </div>
          ))}
        </div>
        <div className="bg-white p-6 rounded-lg text-center">
          <p className="text-lg font-semibold text-gray-900 mb-2">🎯 Bottom line: +$4,200/month profit from the same ad budget</p>
          <p className="text-gray-600">Tracking turns guesswork into math.</p>
        </div>
      </div>
    </div>
  );
}
