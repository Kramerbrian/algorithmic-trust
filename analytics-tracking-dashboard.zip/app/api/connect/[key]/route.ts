import { NextRequest, NextResponse } from 'next/server';
import { ConnectorKey, ConnectBody } from '@/lib/zod';
import { USE_MOCK } from '@/lib/config';

export async function POST(req: NextRequest, { params }: { params: { key: string } }) {
  const key = ConnectorKey.safeParse(params.key);
  if (!key.success) return NextResponse.json({ error: 'invalid connector' }, { status: 400 });

  const json = await req.json().catch(() => ({}));
  const body = ConnectBody.safeParse(json);
  if (!body.success) return NextResponse.json({ error: body.error.flatten() }, { status: 400 });

  if (USE_MOCK) {
    return NextResponse.json({ ok: true });
  }

  // TODO: Implement real integrations.
  return NextResponse.json({ error: `connector '${key.data}' integration not configured` }, { status: 501 });
}
