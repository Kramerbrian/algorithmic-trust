import { NextRequest, NextResponse } from 'next/server';
import { ConnectorKey } from '@/lib/zod';
import { USE_MOCK } from '@/lib/config';
import { CONNECTORS } from '@/lib/connectors';

export async function GET(_: NextRequest, { params }: { params: { key: string } }) {
  const key = ConnectorKey.safeParse(params.key);
  if (!key.success) return NextResponse.json({ error: 'invalid connector' }, { status: 400 });

  if (USE_MOCK) {
    return NextResponse.json({ data: CONNECTORS[key.data].mock });
  }

  // TODO: Implement real fetch to GA4 or Meta.
  return NextResponse.json({ error: `metrics for '${key.data}' not configured` }, { status: 501 });
}
