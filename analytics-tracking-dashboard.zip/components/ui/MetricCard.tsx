export default function MetricCard({ label, value, change, up, prefix = '', suffix = '' }: {
  label: string; value: number|string; change?: number; up?: boolean; prefix?: string; suffix?: string;
}) {
  return (
    <div className="bg-gray-50 p-5 rounded-lg border-l-4 border-blue-500">
      <div className="text-sm text-gray-600 mb-2 font-medium">{label}</div>
      <div className="text-2xl font-bold text-gray-900 mb-2">
        {prefix}{typeof value === 'number' ? value.toLocaleString() : value}{suffix}
      </div>
      {change !== undefined && (
        <div className={`text-sm font-semibold ${up ? 'text-green-600' : 'text-red-600'}`}>
          {up ? '↑' : '↓'} {Math.abs(change)}% vs last month
        </div>
      )}
    </div>
  );
}
