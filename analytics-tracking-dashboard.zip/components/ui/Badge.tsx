export default function Badge({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div className={`px-3 py-1.5 rounded-full text-sm font-semibold flex items-center gap-2 ${ok ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
      <span className={`w-2 h-2 rounded-full ${ok ? 'bg-green-500' : 'bg-red-500'}`} />
      {label}
    </div>
  );
}
