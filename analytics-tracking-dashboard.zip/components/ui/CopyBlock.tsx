'use client';
import React from 'react';

export default function CopyBlock({ title, code }: { title: string; code: string }) {
  const [copied, setCopied] = React.useState(false);
  return (
    <div>
      <h3 className="text-lg font-semibold mb-3">{title}</h3>
      <div className="bg-gray-900 text-gray-100 p-4 rounded-lg relative">
        <button
          onClick={() => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 900); }}
          className="absolute top-2 right-2 px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700"
        >
          {copied ? 'Copied' : 'Copy'}
        </button>
        <pre className="text-sm overflow-x-auto whitespace-pre-wrap">{code}</pre>
      </div>
    </div>
  );
}
