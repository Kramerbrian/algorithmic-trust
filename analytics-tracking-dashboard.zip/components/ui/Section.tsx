export default function Section({ icon, title, children }: React.PropsWithChildren<{ icon: string; title: string }>) {
  return (
    <div className="bg-white rounded-xl p-6 mb-8 shadow-sm">
      <div className="flex items-center gap-3 mb-6 pb-4 border-b-2 border-gray-200">
        <span className="text-2xl">{icon}</span>
        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      </div>
      {children}
    </div>
  );
}
