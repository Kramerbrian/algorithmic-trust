'use client';
import { useEffect } from 'react';
import { useToastStore } from '@/lib/toast';

export default function Toasts() {
  const { toasts, remove } = useToastStore();
  useEffect(() => {
    const timers = toasts.map(t => setTimeout(() => remove(t.id), 3000));
    return () => { timers.forEach(clearTimeout); };
  }, [toasts, remove]);
  return (
    <div className="fixed bottom-4 right-4 space-y-2 z-50">
      {toasts.map(t => (
        <div key={t.id} className="bg-gray-900 text-white px-4 py-3 rounded-lg shadow">
          <div className="font-semibold">{t.title}</div>
          {t.desc && <div className="text-sm opacity-80">{t.desc}</div>}
        </div>
      ))}
    </div>
  );
}
