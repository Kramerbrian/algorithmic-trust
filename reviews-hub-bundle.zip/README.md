# Reviews Hub Bundle

Drop-in integration for Google Business Profile, Yelp, and Facebook reviews with OpenAI drafting and Supabase storage.

## Install
```bash
npm i googleapis openai @supabase/supabase-js
```

## Env
Copy `.env.example` to `.env.local` and fill values. Place the GBP service account JSON at `./secrets/gbp-service-account.json` and add that account as an Owner on your GBP location.

## DB
Run `scripts/reviews-schema.sql` in Supabase SQL editor.

Seed a dealer:
```sql
insert into dealers (id, name, city, state, google_location_id)
values ('00000000-0000-0000-0000-000000000001','Test Toyota','Naples','FL','<GBP_LOCATION_ID>')
on conflict (id) do nothing;
```

## Routes
- `POST /api/reviews/aggregate` { dealershipId }
- `POST /api/reviews/respond` { dealershipId, reviewId, responseText }
- `GET  /api/reviews/list?dealershipId=...&limit=50&page=1`
- `GET  /api/reviews/aggregate-all` (cron)
- `POST /api/reviews/aggregate-all` { dealershipId }

## UI
Mount `components/ReviewsHub.tsx` in your dashboard and pass `dealershipId`.

## Smoke tests
```bash
curl -s -X POST http://localhost:3000/api/reviews/aggregate-all -H "content-type: application/json" -d '{"dealershipId":"00000000-0000-0000-0000-000000000001"}'
curl -s "http://localhost:3000/api/reviews/list?dealershipId=00000000-0000-0000-0000-000000000001&limit=5"
```

## Notes
- Yelp replies require partner R2R; disabled by default.
- Facebook uses Graph API v20.0 by default; provide a valid Page Access Token.
- Google replies use `accounts/{accountId}/locations/{locationId}/reviews/{reviewId}`.
