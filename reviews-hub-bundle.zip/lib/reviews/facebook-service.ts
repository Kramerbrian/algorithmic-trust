interface FacebookReview {
  created_time: string;
  reviewer: { name: string; id: string };
  rating: number;
  review_text?: string;
  recommendation_type: 'positive' | 'negative' | 'no_recommendation';
}

export class FacebookService {
  private accessToken: string;
  private apiVersion: string;
  private baseUrl: string;

  constructor() {
    this.accessToken = process.env.FACEBOOK_ACCESS_TOKEN as string;
    if (!this.accessToken) throw new Error('Missing FACEBOOK_ACCESS_TOKEN');
    this.apiVersion = process.env.FB_GRAPH_VERSION || 'v20.0';
    this.baseUrl = `https://graph.facebook.com/${this.apiVersion}`;
  }

  async getPageReviews(pageId: string): Promise<FacebookReview[]> {
    const url = `${this.baseUrl}/${pageId}/ratings?fields=created_time,reviewer,rating,review_text,recommendation_type&access_token=${this.accessToken}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Facebook API error: ${res.status}`);
    const data = await res.json();
    return data.data ?? [];
  }

  async respondToReview(_pageId: string, reviewId: string, message: string): Promise<boolean> {
    const url = `${this.baseUrl}/${reviewId}/comments`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, access_token: this.accessToken }),
    });
    return res.ok;
  }
}
