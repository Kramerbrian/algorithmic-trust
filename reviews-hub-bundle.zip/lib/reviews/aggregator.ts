import { GoogleBusinessService } from './google-business';
import { YelpService } from './yelp-service';
import { FacebookService } from './facebook-service';
import { OpenAIResponseService } from './openai-service';

export interface UnifiedReview {
  id: string;
  platform: 'google' | 'yelp' | 'facebook' | 'dealerrater';
  author: string;
  rating: number;
  text: string;
  date: string;
  responded: boolean;
  responseText?: string;
  responseDate?: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
  sentimentConfidence?: number;
  aspects?: string[];
  urgency?: 'low' | 'medium' | 'high';
  draftResponse?: string;
}

export class ReviewAggregator {
  private googleService: GoogleBusinessService;
  private yelpService: YelpService;
  private facebookService: FacebookService;
  private openaiService: OpenAIResponseService;

  constructor() {
    this.googleService = new GoogleBusinessService();
    this.yelpService = new YelpService();
    this.facebookService = new FacebookService();
    this.openaiService = new OpenAIResponseService();
  }

  async aggregateAllReviews(dealerInfo: {
    name: string;
    googleLocationId?: string;
    yelpBusinessId?: string;
    facebookPageId?: string;
    location: string;
  }): Promise<UnifiedReview[]> {
    const allReviews: UnifiedReview[] = [];

    const [googleReviews, yelpReviews, facebookReviews] = await Promise.all([
      this.fetchGoogleReviews(dealerInfo.googleLocationId),
      this.fetchYelpReviews(dealerInfo.yelpBusinessId, dealerInfo.name, dealerInfo.location),
      this.fetchFacebookReviews(dealerInfo.facebookPageId)
    ]);

    allReviews.push(...googleReviews, ...yelpReviews, ...facebookReviews);

    for (const review of allReviews) {
      if (review.text && !review.responded) {
        try {
          const analysis = await this.openaiService.analyzeSentiment(review.text);
          review.sentiment = analysis.sentiment;
          review.sentimentConfidence = analysis.confidence;
          review.aspects = analysis.aspects;

          const draft = await this.openaiService.draftResponse({
            text: review.text,
            rating: review.rating,
            platform: review.platform,
            dealershipName: dealerInfo.name
          });
          review.draftResponse = draft.content;
          review.urgency = draft.urgency;
        } catch (error) {
          console.error(`Analysis failed for review ${review.id}:`, error);
        }
      }
    }

    return allReviews.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  private async fetchGoogleReviews(locationId?: string): Promise<UnifiedReview[]> {
    if (!locationId) return [];
    try {
      const reviews = await this.googleService.getLocationReviews(locationId);
      return reviews.map(r => {
        const reviewId = r.name.split('/').pop() as string;
        return {
          id: `${process.env.GBP_ACCOUNT_ID}_${locationId}_${reviewId}`,
          platform: 'google' as const,
          author: r.reviewer.displayName,
          rating: this.convertGoogleRating(r.starRating),
          text: r.comment || '',
          date: r.createTime,
          responded: !!r.reviewReply,
          responseText: r.reviewReply?.comment,
          responseDate: r.reviewReply?.updateTime
        };
      });
    } catch (error) {
      console.error('Google reviews fetch failed:', error);
      return [];
    }
  }

  private async fetchYelpReviews(businessId?: string, businessName?: string, location?: string): Promise<UnifiedReview[]> {
    try {
      let finalBusinessId = businessId;
      if (!finalBusinessId && businessName && location) {
        const business = await this.yelpService.findBusinessByName(businessName, location);
        finalBusinessId = business?.id;
      }
      if (!finalBusinessId) return [];

      const reviews = await this.yelpService.getBusinessReviews(finalBusinessId);
      return reviews.map(r => ({
        id: r.id,
        platform: 'yelp' as const,
        author: r.user.name,
        rating: r.rating,
        text: r.text,
        date: r.time_created,
        responded: false
      }));
    } catch (error) {
      console.error('Yelp reviews fetch failed:', error);
      return [];
    }
  }

  private async fetchFacebookReviews(pageId?: string): Promise<UnifiedReview[]> {
    if (!pageId) return [];
    try {
      const reviews = await this.facebookService.getPageReviews(pageId);
      return reviews.map(r => ({
        id: `fb_${r.reviewer.id}_${r.created_time}`,
        platform: 'facebook' as const,
        author: r.reviewer.name,
        rating: r.rating,
        text: r.review_text || '',
        date: r.created_time,
        responded: false
      }));
    } catch (error) {
      console.error('Facebook reviews fetch failed:', error);
      return [];
    }
  }

  private convertGoogleRating(starRating: string): number {
    const ratingMap: Record<string, number> = { 'ONE': 1, 'TWO': 2, 'THREE': 3, 'FOUR': 4, 'FIVE': 5 };
    return ratingMap[starRating] ?? 3;
  }

  async sendResponse(
    review: UnifiedReview,
    responseText: string,
    dealerInfo: any
  ): Promise<boolean> {
    try {
      switch (review.platform) {
        case 'google': {
          const locationId = (review.id.split('_')[1]); // from deterministic id
          const reviewId = (review.id.split('_')[2]);
          return await this.googleService.replyToReview(locationId, reviewId, responseText);
        }
        case 'facebook': {
          // review.id includes fb_<reviewerId>_<created_time>; FB needs review object id. Keep manual unless mapped.
          return false;
        }
        case 'yelp':
        default:
          return false;
      }
    } catch (error) {
      console.error(`Failed to send response to ${review.platform}:`, error);
      return false;
    }
  }
}
