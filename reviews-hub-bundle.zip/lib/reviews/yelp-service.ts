interface YelpReview {
  id: string;
  rating: number;
  user: { id: string; profile_url: string; image_url?: string; name: string };
  text: string;
  time_created: string;
  url: string;
}

export class YelpService {
  private apiKey: string;
  private baseUrl = 'https://api.yelp.com/v3';

  constructor() {
    this.apiKey = process.env.YELP_API_KEY as string;
    if (!this.apiKey) throw new Error('Missing YELP_API_KEY');
  }

  async getBusinessReviews(businessId: string): Promise<YelpReview[]> {
    const res = await fetch(`${this.baseUrl}/businesses/${businessId}/reviews`, {
      headers: { Authorization: `Bearer ${this.apiKey}`, Accept: 'application/json' },
    });
    if (!res.ok) throw new Error(`Yelp API error: ${res.status}`);
    const data = await res.json();
    return data.reviews ?? [];
  }

  async findBusinessByName(name: string, location: string) {
    const url = `${this.baseUrl}/businesses/search?term=${encodeURIComponent(
      name
    )}&location=${encodeURIComponent(location)}&limit=1`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${this.apiKey}`, Accept: 'application/json' },
    });
    if (!res.ok) throw new Error(`Yelp search error: ${res.status}`);
    const data = await res.json();
    return data.businesses?.[0] ?? null;
  }
}
