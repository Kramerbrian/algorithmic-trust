import { google } from 'googleapis';

interface GoogleReview {
  name: string; // reviews/{reviewId}
  starRating: 'ONE' | 'TWO' | 'THREE' | 'FOUR' | 'FIVE';
  comment?: string;
  createTime: string;
  updateTime?: string;
  reviewer: {
    profilePhotoUrl?: string;
    displayName: string;
  };
  reviewReply?: {
    comment: string;
    updateTime: string;
  };
}

export class GoogleBusinessService {
  private auth: any;
  private accountId: string;

  constructor() {
    this.auth = new google.auth.GoogleAuth({
      keyFile: process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE,
      scopes: ['https://www.googleapis.com/auth/business.manage'],
    });
    this.accountId = process.env.GBP_ACCOUNT_ID as string;
    if (!this.accountId) throw new Error('Missing GBP_ACCOUNT_ID');
  }

  async getLocationReviews(locationId: string): Promise<GoogleReview[]> {
    const authClient = await this.auth.getClient();
    const mybusiness = google.mybusinessaccountmanagement({
      version: 'v1',
      auth: authClient,
    });

    const all: GoogleReview[] = [];
    let pageToken: string | undefined;

    do {
      const res = await mybusiness.locations.reviews.list({
        parent: `locations/${locationId}`,
        pageToken,
      });
      if (res.data.reviews?.length) all.push(...res.data.reviews);
      pageToken = res.data.nextPageToken ?? undefined;
    } while (pageToken);

    return all;
  }

  async replyToReview(
    locationId: string,
    reviewId: string,
    replyText: string
  ): Promise<boolean> {
    const authClient = await this.auth.getClient();
    const mybusiness = google.mybusinessaccountmanagement({
      version: 'v1',
      auth: authClient,
    });

    // accounts/{accountId}/locations/{locationId}/reviews/{reviewId}
    const name = `accounts/${this.accountId}/locations/${locationId}/reviews/${reviewId}`;

    await mybusiness.accounts.locations.reviews.updateReply({
      name,
      requestBody: { comment: replyText },
    });

    return true;
  }

  async getLocationInfo(placeId: string) {
    const authClient = await this.auth.getClient();
    const mybusiness = google.mybusinessaccountmanagement({
      version: 'v1',
      auth: authClient,
    });

    const response = await mybusiness.locations.get({
      name: `locations/${placeId}`,
    });

    return response.data ?? null;
  }
}
