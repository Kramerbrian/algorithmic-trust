import OpenAI from 'openai';

interface ResponseDraft {
  content: string;
  tone: 'professional' | 'empathetic' | 'apologetic' | 'grateful';
  urgency: 'low' | 'medium' | 'high';
  template: string;
}

const RESP_MODEL = process.env.OPENAI_MODEL_RESPONSES || 'gpt-4o-mini';
const ANA_MODEL  = process.env.OPENAI_MODEL_ANALYSIS  || 'gpt-4o-mini';

export class OpenAIResponseService {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY as string });
  }

  async draftResponse(review: {
    text: string;
    rating: number;
    platform: string;
    dealershipName: string;
    managerName?: string;
  }): Promise<ResponseDraft> {
    const sentiment = review.rating >= 4 ? 'positive' : review.rating >= 3 ? 'neutral' : 'negative';

    const systemPrompt = `You are a professional dealership manager responding to customer reviews.

Guidelines:
- Under 150 words
- Authentic and personal
- Positive: thank specifically
- Negative: acknowledge, apologize, offer direct contact
- Manager: ${review.managerName || '[Manager Name]'}
- Dealer: ${review.dealershipName}
- Platform: ${review.platform}

Tone:
- 5★ grateful
- 4★ appreciative
- 3★ improvement-focused
- 1–2★ apologetic+solution-oriented`;

    const completion = await this.openai.chat.completions.create({
      model: RESP_MODEL,
      messages: [
        { role: 'system', content: systemPrompt },
        {
          role: 'user',
          content: `Review (${review.rating} stars): "${review.text}"\nDraft a ${sentiment} response that addresses their specific points.`,
        },
      ],
      max_tokens: 200,
      temperature: 0.7,
    });

    const content = completion.choices[0]?.message?.content?.trim() || '';
    return {
      content,
      tone:
        sentiment === 'positive' ? 'grateful' :
        sentiment === 'neutral'  ? 'professional' : 'apologetic',
      urgency: review.rating <= 2 ? 'high' : review.rating === 3 ? 'medium' : 'low',
      template: this.getTemplate(sentiment),
    };
  }

  private getTemplate(sentiment: string): string {
    const templates = {
      positive: 'grateful_thanks',
      neutral: 'improvement_focused',
      negative: 'apologetic_resolution',
    } as const;
    return templates[sentiment as keyof typeof templates] || 'professional_standard';
  }

  async analyzeSentiment(text: string): Promise<{
    sentiment: 'positive' | 'negative' | 'neutral';
    confidence: number;
    aspects: string[];
  }> {
    const completion = await this.openai.chat.completions.create({
      model: ANA_MODEL,
      messages: [
        {
          role: 'system',
          content:
            'Return strict JSON only: {"sentiment":"positive|negative|neutral","confidence":0.0-1.0,"aspects":["service","pricing","staff"]}',
        },
        { role: 'user', content: text },
      ],
      max_tokens: 120,
      temperature: 0.1,
    });

    const raw = completion.choices[0]?.message?.content ?? '{}';
    const match = raw.match(/\{[\s\S]*\}/);
    let parsed: any = {};
    try {
      parsed = JSON.parse(match ? match[0] : raw);
    } catch {
      parsed = {};
    }

    const s = parsed.sentiment;
    const c = Number(parsed.confidence);
    const a = Array.isArray(parsed.aspects) ? parsed.aspects : [];

    return {
      sentiment: s === 'positive' || s === 'negative' || s === 'neutral' ? s : 'neutral',
      confidence: Number.isFinite(c) ? Math.max(0, Math.min(1, c)) : 0.5,
      aspects: a.map(String),
    };
  }
}
