import { NextRequest, NextResponse } from 'next/server';
import { ReviewAggregator } from '@/lib/reviews/aggregator';
import { supabaseAdmin } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { reviewId, responseText, dealershipId } = body;

    const [reviewResult, dealerResult] = await Promise.all([
      supabaseAdmin.from('reviews').select('*').eq('id', reviewId).single(),
      supabaseAdmin.from('dealers').select('*').eq('id', dealershipId).single()
    ]);

    if (reviewResult.error || !reviewResult.data || dealerResult.error || !dealerResult.data) {
      return NextResponse.json({ error: 'Review or dealer not found' }, { status: 404 });
    }

    const review = reviewResult.data as any;
    const dealer = dealerResult.data as any;
    const aggregator = new ReviewAggregator();

    const success = await aggregator.sendResponse(
      review,
      responseText,
      {
        googleLocationId: dealer.google_location_id,
        facebookPageId: dealer.facebook_page_id
      }
    );

    if (success) {
      await supabaseAdmin
        .from('reviews')
        .update({
          responded: true,
          response_text: responseText,
          response_date: new Date().toISOString()
        })
        .eq('id', reviewId);
    }

    return NextResponse.json({
      success,
      message: success ? 'Response sent successfully' : 'Failed to send response'
    });

  } catch (error: any) {
    console.error('Review response error:', error);
    return NextResponse.json({ error: 'Failed to send response' }, { status: 500 });
  }
}
