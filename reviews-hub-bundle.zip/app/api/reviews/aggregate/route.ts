import { NextRequest, NextResponse } from 'next/server';
import { ReviewAggregator } from '@/lib/reviews/aggregator';
import { supabaseAdmin } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dealershipId } = body;

    const { data: dealer, error } = await supabaseAdmin
      .from('dealers')
      .select('*')
      .eq('id', dealershipId)
      .single();

    if (error || !dealer) {
      return NextResponse.json({ error: 'Dealership not found' }, { status: 404 });
    }

    const aggregator = new ReviewAggregator();

    const reviews = await aggregator.aggregateAllReviews({
      name: dealer.name,
      googleLocationId: dealer.google_location_id || undefined,
      yelpBusinessId: dealer.yelp_business_id || undefined,
      facebookPageId: dealer.facebook_page_id || undefined,
      location: `${dealer.city}, ${dealer.state}`
    });

    const rows = reviews.map((r:any) => ({
      id: r.id,
      dealer_id: dealershipId,
      platform: r.platform,
      author: r.author,
      rating: r.rating,
      text: r.text,
      review_date: r.date,
      responded: r.responded,
      response_text: r.responseText ?? null,
      response_date: r.responseDate ?? null,
      sentiment: r.sentiment ?? null,
      sentiment_confidence: r.sentimentConfidence ?? null,
      aspects: r.aspects ?? null,
      urgency: r.urgency ?? null,
      draft_response: r.draftResponse ?? null,
      updated_at: new Date().toISOString()
    }));

    for (let i = 0; i < rows.length; i += 500) {
      const chunk = rows.slice(i, i + 500);
      const { error: upErr } = await supabaseAdmin
        .from('reviews')
        .upsert(chunk, { onConflict: 'id' });
      if (upErr) throw upErr;
    }

    return NextResponse.json({
      success: true,
      reviewCount: reviews.length,
      reviews: reviews.slice(0, 20)
    });

  } catch (error: any) {
    console.error('Review aggregation error:', error);
    return NextResponse.json({ error: 'Failed to aggregate reviews' }, { status: 500 });
  }
}
