import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase/server';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const dealershipId = searchParams.get('dealershipId');
  const limit = Number(searchParams.get('limit') || 50);
  const page = Number(searchParams.get('page') || 1);
  if (!dealershipId) return NextResponse.json({ error: 'dealershipId required' }, { status: 400 });

  const from = (page - 1) * limit;
  const to = from + limit - 1;

  const { data, error, count } = await supabaseAdmin
    .from('reviews')
    .select('*', { count: 'exact' })
    .eq('dealer_id', dealershipId)
    .order('review_date', { ascending: false })
    .range(from, to);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ items: data, page, limit, total: count ?? 0 });
}
