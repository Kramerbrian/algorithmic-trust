import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase/server';
import { ReviewAggregator } from '@/lib/reviews/aggregator';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const { data: dealers, error } = await supabaseAdmin
      .from('dealers')
      .select('id,name,city,state,google_location_id,yelp_business_id,facebook_page_id')
      .or('google_location_id.not.is.null,yelp_business_id.not.is.null,facebook_page_id.not.is.null');

    if (error) throw error;
    if (!dealers?.length) return NextResponse.json({ success: true, processed: 0 });

    const aggregator = new ReviewAggregator();
    let total = 0;

    for (const d of dealers) {
      const reviews = await aggregator.aggregateAllReviews({
        name: d.name,
        googleLocationId: d.google_location_id || undefined,
        yelpBusinessId: d.yelp_business_id || undefined,
        facebookPageId: d.facebook_page_id || undefined,
        location: `${d.city}, ${d.state}`,
      });

      if (reviews.length) {
        const rows = reviews.map((r:any) => ({
          id: r.id,
          dealer_id: d.id,
          platform: r.platform,
          author: r.author,
          rating: r.rating,
          text: r.text,
          review_date: r.date,
          responded: r.responded,
          response_text: r.responseText ?? null,
          response_date: r.responseDate ?? null,
          sentiment: r.sentiment ?? null,
          sentiment_confidence: r.sentimentConfidence ?? null,
          aspects: r.aspects ?? null,
          urgency: r.urgency ?? null,
          draft_response: r.draftResponse ?? null,
          updated_at: new Date().toISOString(),
        }));

        for (let i = 0; i < rows.length; i += 500) {
          const chunk = rows.slice(i, i + 500);
          const { error: upErr } = await supabaseAdmin
            .from('reviews')
            .upsert(chunk, { onConflict: 'id' });
          if (upErr) throw upErr;
        }
        total += reviews.length;
      }
    }
    return NextResponse.json({ success: true, processed: dealers.length, reviewsUpserted: total });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'aggregate-all failed' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const { dealershipId } = await req.json();
  if (!dealershipId) return NextResponse.json({ error: 'dealershipId required' }, { status: 400 });

  const { data: d, error } = await supabaseAdmin
    .from('dealers')
    .select('*').eq('id', dealershipId).single();
  if (error || !d) return NextResponse.json({ error: 'dealer not found' }, { status: 404 });

  const aggregator = new ReviewAggregator();
  const reviews = await aggregator.aggregateAllReviews({
    name: d.name,
    googleLocationId: d.google_location_id || undefined,
    yelpBusinessId: d.yelp_business_id || undefined,
    facebookPageId: d.facebook_page_id || undefined,
    location: `${d.city}, ${d.state}`,
  });

  if (reviews.length) {
    const rows = reviews.map((r:any) => ({
      id: r.id, dealer_id: dealershipId, platform: r.platform, author: r.author,
      rating: r.rating, text: r.text, review_date: r.date, responded: r.responded,
      response_text: r.responseText ?? null, response_date: r.responseDate ?? null,
      sentiment: r.sentiment ?? null, sentiment_confidence: r.sentimentConfidence ?? null,
      aspects: r.aspects ?? null, urgency: r.urgency ?? null, draft_response: r.draftResponse ?? null,
      updated_at: new Date().toISOString(),
    }));
    const { error: upErr } = await supabaseAdmin.from('reviews').upsert(rows, { onConflict: 'id' });
    if (upErr) return NextResponse.json({ error: upErr.message }, { status: 500 });
  }
  return NextResponse.json({ success: true, reviewCount: reviews.length });
}
