'use client';
import React, { useEffect, useMemo, useState } from 'react';

type Review = {
  id: string; platform: 'google'|'yelp'|'facebook'|'dealerrater';
  author: string; rating: number; text: string; review_date: string;
  responded: boolean; sentiment?: 'positive'|'negative'|'neutral'; urgency?: 'low'|'medium'|'high';
  draft_response?: string;
};

export default function ReviewsHub({ dealershipId }: { dealershipId: string }) {
  const [items, setItems] = useState<Review[]>([]);
  const [loading, setLoading] = useState(false);
  const [replyId, setReplyId] = useState<string|null>(null);
  const [replyText, setReplyText] = useState('');

  const load = async () => {
    setLoading(true);
    const res = await fetch(`/api/reviews/list?dealershipId=${dealershipId}&limit=100`);
    const json = await res.json();
    setItems(json.items || []);
    setLoading(false);
  };

  useEffect(() => { if (dealershipId) load(); }, [dealershipId]);

  const summary = useMemo(() => {
    const total = items.length;
    const pending = items.filter(i => !i.responded).length;
    const negatives = items.filter(i => i.sentiment === 'negative').length;
    const avg = items.length ? (items.reduce((a,b)=>a+b.rating,0)/items.length).toFixed(2) : '0.00';
    return { total, pending, negatives, avg };
  }, [items]);

  const refresh = async () => {
    setLoading(true);
    await fetch('/api/reviews/aggregate-all', { method: 'POST', body: JSON.stringify({ dealershipId }), headers: {'content-type':'application/json'} });
    await load();
  };

  const sendReply = async () => {
    if (!replyId) return;
    const res = await fetch('/api/reviews/respond', {
      method: 'POST',
      headers: {'content-type':'application/json'},
      body: JSON.stringify({ reviewId: replyId, responseText: replyText, dealershipId })
    });
    const ok = (await res.json()).success;
    if (ok) { setReplyId(null); setReplyText(''); await load(); }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-4 gap-3">
        <Stat title="Reviews" value={summary.total} />
        <Stat title="Pending" value={summary.pending} />
        <Stat title="Negative" value={summary.negatives} />
        <Stat title="Avg ★" value={summary.avg} />
      </div>

      <div className="flex gap-2">
        <button onClick={refresh} className="px-3 py-2 rounded bg-black text-white disabled:opacity-50" disabled={loading}>
          {loading ? 'Updating…' : 'Refresh'}
        </button>
      </div>

      <div className="divide-y border rounded">
        {items.map(r => (
          <div key={r.id} className="p-4 flex gap-4 items-start">
            <Badge>{r.platform}</Badge>
            <div className="flex-1">
              <div className="flex items-center gap-2 text-sm">
                <span className="font-medium">{r.author}</span>
                <span>•</span>
                <span>{new Date(r.review_date).toLocaleString()}</span>
                <span>•</span>
                <span>{'★'.repeat(r.rating)}</span>
                {r.sentiment && <span className="ml-2 text-xs opacity-70">[{r.sentiment}]</span>}
              </div>
              <p className="mt-2 text-sm">{r.text}</p>
              {!r.responded && (
                <div className="mt-3">
                  <textarea
                    className="w-full border rounded p-2 text-sm"
                    placeholder={r.draft_response || 'Write a reply…'}
                    value={replyId === r.id ? replyText : (r.draft_response || '')}
                    onChange={e => { setReplyId(r.id); setReplyText(e.target.value); }}
                    rows={3}
                  />
                  <div className="mt-2 flex gap-2">
                    <button onClick={() => { setReplyId(r.id); setReplyText(r.draft_response || ''); }} className="px-3 py-1 border rounded text-sm">Use draft</button>
                    <button onClick={sendReply} className="px-3 py-1 bg-blue-600 text-white rounded text-sm">Send reply</button>
                  </div>
                </div>
              )}
              {r.responded && <div className="mt-2 text-xs text-green-700">Responded</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Stat({ title, value }: { title: string; value: string|number }) {
  return (
    <div className="border rounded p-3">
      <div className="text-xs opacity-70">{title}</div>
      <div className="text-xl font-semibold">{value}</div>
    </div>
  );
}
function Badge({ children }: { children: React.ReactNode }) {
  return <span className="px-2 py-0.5 text-xs border rounded uppercase">{children}</span>;
}
