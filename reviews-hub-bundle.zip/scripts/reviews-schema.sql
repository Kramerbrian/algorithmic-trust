-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY,
  dealer_id UUID REFERENCES dealers(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('google', 'yelp', 'facebook', 'dealerrater')),
  author TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  text TEXT,
  review_date TIMESTAMPTZ NOT NULL,
  responded BOOLEAN DEFAULT FALSE,
  response_text TEXT,
  response_date TIMESTAMPTZ,
  sentiment TEXT CHECK (sentiment IN ('positive', 'negative', 'neutral')),
  sentiment_confidence DECIMAL(3,2),
  aspects TEXT[],
  urgency TEXT CHECK (urgency IN ('low', 'medium', 'high')),
  draft_response TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE dealers ADD COLUMN IF NOT EXISTS google_location_id TEXT;
ALTER TABLE dealers ADD COLUMN IF NOT EXISTS yelp_business_id TEXT;
ALTER TABLE dealers ADD COLUMN IF NOT EXISTS facebook_page_id TEXT;
ALTER TABLE dealers ADD COLUMN IF NOT EXISTS dealerrater_id TEXT;

CREATE INDEX IF NOT EXISTS idx_reviews_dealer_platform ON reviews(dealer_id, platform);
CREATE INDEX IF NOT EXISTS idx_reviews_responded ON reviews(responded, review_date DESC);
CREATE INDEX IF NOT EXISTS idx_reviews_urgency ON reviews(urgency, review_date DESC);
CREATE INDEX IF NOT EXISTS idx_reviews_sentiment ON reviews(sentiment, rating);
CREATE INDEX IF NOT EXISTS idx_reviews_aspects ON reviews USING GIN (aspects);

CREATE EXTENSION IF NOT EXISTS moddatetime;
CREATE TRIGGER set_timestamp BEFORE UPDATE ON reviews
FOR EACH ROW EXECUTE PROCEDURE moddatetime (updated_at);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY reviews_service_only ON reviews
  FOR ALL TO PUBLIC
  USING (false) WITH CHECK (false);
