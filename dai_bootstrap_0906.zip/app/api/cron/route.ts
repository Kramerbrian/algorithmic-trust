
import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const runtime = 'nodejs';

export async function GET(req: Request) {
  const auth = req.headers.get('authorization') || '';
  const token = auth.replace('Bearer ','');
  if (token !== process.env.CRON_SECRET) return NextResponse.json({ok:false}, { status: 401 });

  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_KEY!);
  const { data: dealers } = await supabase.from('dealers').select('id, url');

  // enqueue jobs or call visibility route for each dealer
  // For pilot: do a simple loop (respect rate limits)
  let processed = 0;
  for (const d of dealers || []) {
    try {
      await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/engines/visibility?url=${encodeURIComponent(d.url)}`);
      processed++;
    } catch {}
  }

  return NextResponse.json({ ok: true, processed });
}
