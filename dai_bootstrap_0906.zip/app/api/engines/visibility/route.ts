
import { NextResponse } from 'next/server';
import { withCache } from '@/lib/cache';
import { takeToken } from '@/lib/ratelimit';
import { assertBudget } from '@/lib/budget';

export const runtime = 'nodejs'; // server

async function fetchVisibility(dealerUrl: string){
  // TODO: implement headless capture + prompt-set evaluation
  return {
    url: dealerUrl,
    engines: {
      chatgpt: { appeared: false, citations: [] },
      gemini: { appeared: false, citations: [] },
      copilot: { appeared: false, citations: [] },
      grok: { appeared: false, citations: [] },
      perplexity: { appeared: false, citations: [] }
    },
    capturedAt: new Date().toISOString()
  };
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const dealerUrl = searchParams.get('url'); 
  if (!dealerUrl) return NextResponse.json({error:'url required'},{status:400});

  const host = new URL(dealerUrl).hostname;
  if (!(await takeToken(host))) return NextResponse.json({error:'rate_limited'},{status:429});
  await assertBudget('openai', 10); // estimate 10 cents if LLM used

  const key = `vis:${dealerUrl}`;
  const ttl = 60*60*24;   // 24h
  const swr = 60*60*72;   // 72h

  const data = await withCache(key, ttl, swr, async () => await fetchVisibility(dealerUrl));
  return NextResponse.json(data);
}
