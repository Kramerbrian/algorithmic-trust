
/* app/dashboard/page.tsx */
import dynamic from 'next/dynamic';

// If you already have BK_9_1_25_dealership_dashboard.tsx under components/ use that path
const BKDashboard = dynamic(() => import('@/components/BK_9_1_25_dealership_dashboard'), { ssr: false });

export default function DashboardPage() {
  return <div className="min-h-screen bg-neutral-950 text-white"><BKDashboard /></div>;
}
