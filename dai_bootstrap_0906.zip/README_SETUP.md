
# DealershipAI Dashboard Bootstrap

## Quick start
1. `npm ci`
2. Set envs in Vercel & GitHub (already done).
3. Run migrations on Supabase:
   - Upload `supabase/migrations/0001_core.sql` and `0002_staff.sql` via SQL editor.
4. Seed dealers:
   - `npm run seed:dealers` (requires SUPABASE_SERVICE_KEY in local shell)
5. Visit `/dashboard`.

## Cron
- `vercel.json` defines:
  - `/api/cron` daily 06:00 UTC
  - `/api/engines/visibility` bi-weekly 07:00 UTC

## Caching/budget
- Redis SWR in `lib/cache.ts`
- Token bucket in `lib/ratelimit.ts`
- Budget guard in `lib/budget.ts` ($25/provider/month)

## Notes
- Replace the visibility fetcher with your headless/prompt-set implementation.
- Admin endpoints require `CRON_SECRET`.
