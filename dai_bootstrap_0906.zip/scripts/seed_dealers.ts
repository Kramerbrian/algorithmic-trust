
/**
 * scripts/seed_dealers.ts
 * Usage: ts-node scripts/seed_dealers.ts seed/dealers_seed.csv
 */
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const key = process.env.SUPABASE_SERVICE_KEY!;
if (!url || !key) throw new Error('Supabase envs missing');

const supabase = createClient(url, key);

async function main() {
  const csvPath = process.argv[2];
  if (!csvPath) throw new Error('CSV path required');
  const rows = fs.readFileSync(csvPath, 'utf-8').trim().split('\n');
  const header = rows.shift()!;
  for (const line of rows) {
    const [name,url,brand,address,city,state,zip,gbp_place_id] = line.split(',');
    const { data: dealer, error: dErr } = await supabase
      .from('dealers')
      .insert({ name, url, brand })
      .select()
      .single();
    if (dErr) { console.error(dErr); continue; }
    const { error: lErr } = await supabase.from('locations').insert({
      dealer_id: dealer.id, address, city, state, zip, gbp_place_id
    });
    if (lErr) console.error(lErr);
    console.log('Seeded', name);
  }
}
main().catch(e=>{ console.error(e); process.exit(1); });
