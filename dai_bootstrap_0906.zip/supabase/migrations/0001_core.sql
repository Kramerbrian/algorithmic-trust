
-- supabase/migrations/0001_core.sql
-- Created: 2025-09-07T02:32:34.843286Z

create extension if not exists pgcrypto;

-- Dealers and locations
create table if not exists dealers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  brand text,
  url text not null,
  created_at timestamptz not null default now()
);

create table if not exists locations (
  id uuid primary key default gen_random_uuid(),
  dealer_id uuid not null references dealers(id) on delete cascade,
  address text,
  city text,
  state text,
  zip text,
  gbp_place_id text,
  lat double precision,
  lng double precision,
  created_at timestamptz not null default now()
);

-- Prompt sets
create table if not exists prompt_sets (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  version text not null default 'v1',
  payload jsonb not null,
  created_at timestamptz not null default now()
);

-- UGC sources registry
create table if not exists ugc_sources (
  id uuid primary key default gen_random_uuid(),
  name text not null,    -- google, yelp, facebook, instagram, tiktok, youtube, reddit, dealerrater, cars, edmunds, kbb
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  unique(name)
);

-- Visibility checks (per engine/result)
create table if not exists visibility_checks (
  id uuid primary key default gen_random_uuid(),
  dealer_id uuid not null references dealers(id) on delete cascade,
  engine text not null,     -- chatgpt, gemini, copilot, grok, perplexity
  query text not null,
  geo jsonb,                -- { "lat":..., "lng":..., "radius_mi": 50 }
  appeared boolean,
  position integer,
  citations jsonb,
  captured_at timestamptz not null default now()
);

-- Snapshots (generic external pull cache)
create table if not exists snapshots (
  id bigint generated always as identity primary key,
  kind text not null,                 -- 'visibility' | 'reviews' | 'schema'
  dealer_id uuid not null,
  source text not null,               -- 'chatgpt' | 'gemini' | 'yelp' ...
  key_hash text not null,             -- sha256(url or query)
  payload jsonb not null,
  captured_at timestamptz not null default now()
);

-- Usage/budget caps
create table if not exists provider_usage (
  provider text not null,
  month date not null default date_trunc('month', now()),
  cents_spent integer not null default 0,
  limit_cents integer not null default 2500,
  updated_at timestamptz not null default now(),
  primary key (provider, month)
);

-- Audit log (no PII)
create table if not exists audit_log (
  id bigserial primary key,
  actor_id text,
  actor_type text, -- 'system' | 'user' | 'bot'
  action text not null,
  resource text,
  resource_id text,
  ip_hash text,
  user_agent text,
  ts timestamptz not null default now()
);

-- Indexes
create index if not exists idx_visibility_checks_dealer_ts on visibility_checks(dealer_id, captured_at desc);
create index if not exists idx_snapshots_kind_dealer_ts on snapshots(kind, dealer_id, captured_at desc);
create index if not exists idx_snapshots_keyhash on snapshots(key_hash);
create index if not exists idx_provider_usage_month on provider_usage(month);

-- RLS: keep disabled for these system tables; app uses service role for writes.
