
-- supabase/migrations/0002_staff.sql
-- Created: 2025-09-07T02:32:34.843286Z

create extension if not exists pgcrypto;

create table if not exists staff (
  id uuid primary key default gen_random_uuid(),
  dealer_id uuid references dealers(id) on delete cascade,
  location_id uuid references locations(id) on delete set null,
  name text not null,
  role text,
  email_hash text,
  social jsonb not null default '{}'::jsonb,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists ugc_associate_map (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid references staff(id) on delete cascade,
  source text not null,
  handle text not null,
  external_id text,
  created_at timestamptz not null default now(),
  unique (source, handle)
);

create or replace view v_staff_ugc_sources as
select s.id as staff_id, s.name, m.source, m.handle
from staff s
left join ugc_associate_map m on m.staff_id = s.id;
