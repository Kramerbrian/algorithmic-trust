
import { Redis } from '@upstash/redis';

const redis = Redis.fromEnv();

type CacheOpts = { ttlSec?: number; swrSec?: number };

export async function cacheGet<T>(key: string): Promise<{data:T|null, stale:boolean}> {
  const res = await redis.get<[T, number]>(key);
  if (!res) return { data: null, stale: false };
  const [data, exp] = res as any;
  const now = Math.floor(Date.now()/1000);
  return { data, stale: now > exp };
}

export async function cacheSet<T>(key: string, data: T, ttlSec: number, swrSec = 0) {
  const hardExp = Math.floor(Date.now()/1000) + ttlSec + swrSec;
  await redis.set(key, [data, hardExp], { ex: ttlSec + swrSec });
}

export async function withCache<T>(
  key: string,
  ttlSec: number,
  swrSec: number,
  fetcher: () => Promise<T>
): Promise<T> {
  const { data, stale } = await cacheGet<T>(key);
  if (data && !stale) return data;
  if (data && stale) { fetcher().then(d=>cacheSet(key,d,ttlSec,swrSec)).catch(()=>{}); return data; }
  const fresh = await fetcher();
  await cacheSet(key, fresh, ttlSec, swrSec);
  return fresh;
}
