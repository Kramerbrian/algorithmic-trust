
import { Redis } from '@upstash/redis';
const redis = Redis.fromEnv();

export async function takeToken(bucket: string, ratePerSec=0.5, burst=5) {
  const now = Date.now();
  const key = `bucket:${bucket}`;
  const state = (await redis.hmget<number>(key, ['tokens','ts'])) as any;
  let tokens = Number(state?.tokens ?? burst);
  let ts = Number(state?.ts ?? now);
  tokens = Math.min(burst, tokens + (ratePerSec * (now - ts))/1000);
  if (tokens < 1) return false;
  tokens -= 1;
  await redis.hset(key, { tokens, ts: now });
  await redis.expire(key, 3600);
  return true;
}
