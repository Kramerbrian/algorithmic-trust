
import { createClient } from '@supabase/supabase-js';
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_KEY!);

export async function assertBudget(provider:string, estCents:number){
  const month = new Date(); month.setDate(1);
  const { data, error } = await supabase
    .from('provider_usage')
    .select()
    .eq('provider', provider)
    .eq('month', month.toISOString().slice(0,10))
    .maybeSingle();
  const limit = data?.limit_cents ?? 2500;
  const spent = data?.cents_spent ?? 0;
  if (spent + estCents > limit) throw new Error(`budget cap for ${provider}`);
}
